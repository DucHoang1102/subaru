        <footer class="site-footer container">
            <hr />
            <div class="row">
                <div class="col-md-12">
                    <h3> Thông tin liên hệ công ty Subaru: </h3>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <p> <b> Trụ sở: </b> <i> LK5A-28 Làng Việt Kiều Châu Âu, KĐTM Mỗ Lao, P. Mỗ Lao, Q. Hà Đông, T.P Hà Nội. </i> </p>
                    <p> <b> Trung tâm tiếng Nhật: </b> <i> Phụng Châu, Chương Mỹ, Hà Nội </i> </p>
                    <p> <b> Hotline: </b> <i> 0913.200.236 hoặc 0967.971.575 </i> </p>
                    <p> <b> Email: </b> <i> info@subarujp.vn </i> </p>
                </div>
                <div class="col-md-6">
                    <p> <b> Chi nhánh tại Nhật Bản: </b> <br>
                    <i> 1. Chiba , thành phố Matsudo, Daikindaira, 3-183-9 <br> 2. Hiroshima, thành phố Fukuyama, Minami Nariocho 6-26-26 <br> 3. Aichi, thành phố Takahama, Koyucho 4-7-10 </i> </p>
                    <p>© 2020 Subaru. All rights reserved</p>
                </div>
            </div>
        </footer>

    <div id="back-to-top"> <i class="fa fa-chevron-up"></i> </div>

</div>

<?php wp_footer() ?>  

<!-- Subiz --> <script> (function(s, u, b, i, z){ u[i]=u[i]||function(){ u[i].t=+new Date(); (u[i].q=u[i].q||[]).push(arguments); }; z=s.createElement('script'); var zz=s.getElementsByTagName('script')[0]; z.async=1; z.src=b; z.id='subiz-script'; zz.parentNode.insertBefore(z,zz); })(document, window, 'https://widgetv4.subiz.com/static/js/app.js', 'subiz'); subiz('setAccount', 'acqpyljdifxbniebxgbw'); </script> <!-- End Subiz -->
 
</body>

</html>