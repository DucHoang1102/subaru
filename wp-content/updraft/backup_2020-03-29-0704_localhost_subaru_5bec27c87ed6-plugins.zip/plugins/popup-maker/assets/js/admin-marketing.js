/*******************************************************************************
 * Copyright (c) 2019, Code Atlantic LLC
 ******************************************************************************/
(function ($) {
    "use strict";

    window.PUM_Admin = window.PUM_Admin || {};

    $(document).ready(function () {
        $('a[href="edit.php?post_type=popup&page=pum-extensions"]').css({color: "#a0d468"});
    });

}(jQuery));